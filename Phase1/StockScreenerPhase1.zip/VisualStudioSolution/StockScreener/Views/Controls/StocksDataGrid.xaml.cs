﻿

using System.Windows.Controls;

namespace StockScreener.Views.Controls
{
    /// <summary>
    /// Interaction logic for ScreenerParmaters.xaml
    /// </summary>
    public partial class StocksDataGrid : UserControl
    {
        public StocksDataGrid()
        {
            InitializeComponent();
        }
    }
}
