﻿
using System.Windows;
using System.Windows.Controls;

namespace StockScreener.Views
{
    /// <summary>
    /// Interaction logic for ScreenerView.xaml
    /// </summary>
    public partial class ScreenerView : UserControl
    {
        public ScreenerView()
        {
            InitializeComponent();
        }
    }
}
